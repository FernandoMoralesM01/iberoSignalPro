from setuptools import setup, find_packages

setup(
    name='viconpy',
    version='0.1',
    packages=find_packages(),
    author="Fernando Morales Magallon, Pablo Roca Mendoza"
    # Agrega otros metadatos como author, description, etc.
)